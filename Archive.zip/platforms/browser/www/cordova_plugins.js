cordova.define('cordova/plugin_list', function(require, exports, module) {
module.exports = [];
module.exports.metadata = 
// TOP OF METADATA
{
    "cordova-plugin-crosswalk-webview": "2.4.0",
    "cordova-plugin-whitelist": "1.3.3"
}
// BOTTOM OF METADATA
});